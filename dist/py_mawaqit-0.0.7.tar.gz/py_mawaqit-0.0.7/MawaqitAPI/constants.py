'''
    This file contains all the constants used in the project
    Adhan url is the url of the adhan audio file , mp3 format
'''

ADHAN_URL = "https://www.islamcan.com/audio/adhan/azan2.mp3"