# Unofficial Mawaqit Python wrapper
An unofficial Mawaqit wrapper for python. It scrapes the mawaqit website to get the prayer times for a given mosque.
## Docs
> https://riadzx.github.io/py-mawaqit/
