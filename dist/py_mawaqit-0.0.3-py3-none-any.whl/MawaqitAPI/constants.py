#prayer adhan link
ADHAN_URL = "https://www.islamcan.com/audio/adhan/azan2.mp3"