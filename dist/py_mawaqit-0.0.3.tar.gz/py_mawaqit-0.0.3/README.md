# Unofficial Mawaqit Python wrapper

> https://riadzx.github.io/py-mawaqit/reference/
## Generate docs
> pdoc --html . --force -c sort_identifiers=False