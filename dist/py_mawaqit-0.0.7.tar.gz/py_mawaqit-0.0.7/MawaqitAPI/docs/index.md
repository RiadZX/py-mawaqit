# Welcome to MawaqitAPI
For the documentation refer to the `Reference` tab on the left <br>
For an example refer to `ChromeCast Adhan`
