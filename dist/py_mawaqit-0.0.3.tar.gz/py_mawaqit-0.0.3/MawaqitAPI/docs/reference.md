::: mawaqit
::: localMawaqit
::: scraper
::: helper